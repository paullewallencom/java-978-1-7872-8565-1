--  InsertPublishers.sql
--  Inserts one record into the Publishers table.
--  Data Analysis with Java
--  John R. Hubbard
--  May 4 2017

insert into Publishers values (
    'PPL',
    'Packt Publishing Limited',
    'Birmingham',
    'UK',
    'packtpub.com'
)
