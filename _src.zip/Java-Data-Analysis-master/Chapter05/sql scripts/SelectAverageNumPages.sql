--  SelectAverageNumPages.sql
--  Data Analysis with Java
--  John R. Hubbard
--  May 4 2017

select avg(numPages) Average
from Books;
