--  InsertSpecifiedFields.sql
--  Data Analysis with Java
--  John R. Hubbard
--  May 4 2017

insert into Publishers (id, name, city, country)
values ('A-V', 'Akademie-Verlag', 'Berlin', 'DE')
