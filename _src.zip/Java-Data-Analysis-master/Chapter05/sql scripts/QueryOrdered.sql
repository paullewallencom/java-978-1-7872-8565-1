--  QueryOrdered.sql
--  Data Analysis with Java
--  John R. Hubbard
--  May 4 2017

select country, city, name from Publishers
order by country, name;
