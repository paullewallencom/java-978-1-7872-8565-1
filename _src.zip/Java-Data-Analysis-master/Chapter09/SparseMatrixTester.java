/*  Data Analysis with Java
 *  John R. Hubbard
 *  Jul 23, 2017
 */

package dawj.ch09;

import java.util.Map;

public class SparseMatrixTester {
    public static void main(String[] args) {
        Map<Key,Double> map;
    }
    
    class Key {
    
    }
}
